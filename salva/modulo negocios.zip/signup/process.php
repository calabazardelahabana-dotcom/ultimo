<?php
// process.php - Procesa el formulario de registro
session_start();

// Procesar formulario cuando se envía
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Recoger y sanitizar datos
    $firstName = trim($_POST['firstName'] ?? '');
    $lastName = trim($_POST['lastName'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $countryCode = $_POST['countryCode'] ?? '';
    $phone = trim($_POST['phone'] ?? '');
    $businessName = trim($_POST['businessName'] ?? '');
    $commercialName = trim($_POST['commercialName'] ?? '');
    $businessType = $_POST['businessType'] ?? '';
    $yearsOperation = $_POST['yearsOperation'] ?? 0;
    $country = $_POST['country'] ?? '';
    $region = trim($_POST['region'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $postalCode = trim($_POST['postalCode'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';
    $newsletter = isset($_POST['newsletter']) ? 1 : 0;
    
    // Validaciones
    $errors = [];
    
    // Validar campos requeridos
    if (empty($firstName)) $errors[] = "El nombre es requerido";
    if (empty($lastName)) $errors[] = "Los apellidos son requeridos";
    if (empty($email)) $errors[] = "El email es requerido";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "El email no es válido";
    if (empty($phone)) $errors[] = "El teléfono es requerido";
    if (empty($businessName)) $errors[] = "El nombre legal del negocio es requerido";
    if (empty($businessType)) $errors[] = "El tipo de negocio es requerido";
    if (empty($country)) $errors[] = "El país es requerido";
    if (empty($region)) $errors[] = "La región es requerida";
    if (empty($city)) $errors[] = "La ciudad es requerida";
    if (empty($address)) $errors[] = "La dirección es requerida";
    
    // Si hay errores, volver al formulario
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        $_SESSION['form_data'] = $_POST;
        header("Location: index.php");
        exit();
    }
    
    // Guardar datos en sesión para success.php
    $_SESSION['registered_user'] = [
        'name' => $firstName . ' ' . $lastName,
        'email' => $email,
        'business' => $commercialName,
        'business_type' => $businessType
    ];
    
    // Redirigir a página de éxito
    header("Location: success.php");
    exit();
    
} else {
    // Si alguien intenta acceder directamente, redirigir al formulario
    header("Location: index.php");
    exit();
}
?>