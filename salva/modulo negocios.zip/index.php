<?php 
$pageTitle = "Transforma Tu Negocio con una Tienda Online Profesional - MassolaGroup";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="La plataforma más completa para emprendedores cubanos. Crea tu tienda online en minutos con MassolaGroup Business.">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/assets/images/logo-massola.png">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --secondary-gradient: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
            --accent-gradient: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
            --trust-gradient: linear-gradient(135deg, #2196F3 0%, #21CBF3 100%);
            --text-dark: #333;
            --text-light: #666;
            --bg-light: #f8f9ff;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-dark);
            overflow-x: hidden;
        }

        /* Header/Navigation */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
            padding: 15px 0;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .header.scrolled {
            background: rgba(255,255,255,0.98);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo img {
            height: 40px;
            width: auto;
        }

        .logo-text {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text-dark);
        }

        .nav-menu {
            display: flex;
            gap: 30px;
            list-style: none;
        }

        .nav-menu a {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-menu a:hover {
            color: #667eea;
        }

        /* Hero Section */
        .hero {
            background: var(--primary-gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
            padding-top: 80px;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="50" cy="50" r="1" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            animation: float 20s ease-in-out infinite;
        }

        .hero-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
            position: relative;
            z-index: 2;
        }

        .hero-content h1 {
            font-size: 3.5rem;
            font-weight: 700;
            color: white;
            margin-bottom: 20px;
            line-height: 1.2;
            text-shadow: 0 2px 20px rgba(0,0,0,0.3);
            animation: slideInLeft 1s ease-out;
        }

        .hero-content p {
            font-size: 1.2rem;
            color: rgba(255,255,255,0.9);
            margin-bottom: 30px;
            animation: slideInLeft 1s ease-out 0.2s both;
        }

        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            color: white;
            padding: 18px 40px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.1rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            animation: slideInLeft 1s ease-out 0.4s both;
        }

        .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.3);
        }

        .hero-visual {
            position: relative;
            animation: slideInRight 1s ease-out 0.3s both;
        }

        .hero-mockup {
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
            position: relative;
        }

        .phone-mockup, .desktop-mockup {
            background: white;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2);
            position: relative;
        }

        .phone-mockup {
            width: 200px;
            height: 400px;
            position: absolute;
            top: 50px;
            right: -20px;
            z-index: 2;
            animation: float 6s ease-in-out infinite;
        }

        .desktop-mockup {
            width: 100%;
            height: 300px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            animation: float 6s ease-in-out infinite 3s;
        }

        /* Features Section */
        .features {
            padding: 100px 0;
            background: var(--secondary-gradient);
            position: relative;
        }

        .features::before {
            content: '';
            position: absolute;
            top: -100px;
            left: 0;
            right: 0;
            height: 100px;
            background: var(--primary-gradient);
            clip-path: polygon(0 0, 100% 0, 100% 100%, 0 80%);
        }

        .section-header {
            text-align: center;
            margin-bottom: 60px;
        }

        .section-header h2 {
            font-size: 2.5rem;
            color: var(--text-dark);
            margin-bottom: 15px;
            animation: fadeInUp 1s ease-out;
        }

        .section-header p {
            font-size: 1.1rem;
            color: var(--text-light);
            max-width: 600px;
            margin: 0 auto;
            animation: fadeInUp 1s ease-out 0.2s both;
        }

        .features-grid {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 40px;
        }

        .feature-card {
            background: white;
            padding: 40px 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            text-align: center;
            transition: all 0.3s ease;
            animation: fadeInUp 1s ease-out;
        }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
        }

        .feature-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            background: var(--primary-gradient);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: white;
        }

        .feature-card h3 {
            font-size: 1.3rem;
            color: var(--text-dark);
            margin-bottom: 15px;
        }

        .feature-card p {
            color: var(--text-light);
            line-height: 1.7;
        }

        /* Trust Section - CORREGIDA */
        .trust-section {
            padding: 100px 0;
            background: var(--trust-gradient);
            color: white;
            position: relative;
        }

        .trust-section::before {
            content: '';
            position: absolute;
            top: -100px;
            left: 0;
            right: 0;
            height: 100px;
            background: var(--secondary-gradient);
            clip-path: polygon(0 0, 100% 0, 100% 100%, 0 80%);
        }

        .trust-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 0 20px;
            text-align: center;
            position: relative;
            z-index: 2;
        }

        .trust-section h2 {
            font-size: 2.5rem;
            margin-bottom: 40px;
            text-shadow: 0 2px 20px rgba(0,0,0,0.3);
        }

        .trust-content {
            font-size: 1.1rem;
            line-height: 1.8;
            margin-bottom: 40px;
            color: rgba(255,255,255,0.95);
        }

        .trust-content p {
            margin-bottom: 20px;
        }

        .trust-content strong {
            color: white;
            font-weight: 600;
        }

        .trust-link {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 15px 30px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 20px;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.3);
        }

        .trust-link:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        /* Plans Section */
        .plans {
            padding: 100px 0;
            background: var(--bg-light);
            position: relative;
        }

        .plans::before {
            content: '';
            position: absolute;
            top: -100px;
            left: 0;
            right: 0;
            height: 100px;
            background: var(--trust-gradient);
            clip-path: polygon(0 0, 100% 0, 100% 100%, 0 80%);
        }

        .plans-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .plans-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 30px;
            margin-top: 60px;
        }

        .plan-card {
            background: white;
            border-radius: 20px;
            padding: 40px 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            position: relative;
            transition: all 0.3s ease;
            animation: fadeInUp 1s ease-out;
        }

        .plan-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
        }

        .plan-card.featured {
            transform: scale(1.05);
            background: var(--primary-gradient);
            color: white;
        }

        .plan-card.featured:hover {
            transform: scale(1.05) translateY(-5px);
        }

        .plan-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .plan-name {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .plan-features {
            list-style: none;
            margin: 30px 0;
        }

        .plan-features li {
            padding: 8px 0;
            position: relative;
            padding-left: 25px;
        }

        .plan-features li::before {
            content: '✓';
            position: absolute;
            left: 0;
            color: #28a745;
            font-weight: bold;
        }

        .plan-card.featured .plan-features li::before {
            color: rgba(255,255,255,0.9);
        }

        .plan-pricing {
            text-align: center;
            margin: 30px 0;
        }

        .plan-price {
            font-size: 1.1rem;
            font-weight: 600;
            background: var(--accent-gradient);
            padding: 15px;
            border-radius: 10px;
            margin: 10px 0;
        }

        .plan-card.featured .plan-price {
            background: rgba(255,255,255,0.2);
            color: white;
        }

        .plan-button {
            display: block;
            width: 100%;
            padding: 15px;
            background: var(--primary-gradient);
            color: white;
            text-decoration: none;
            text-align: center;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .plan-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }

        .plan-card.featured .plan-button {
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
        }

        /* Footer - MODIFICADO */
        .footer {
            background: var(--text-dark);
            color: white;
            padding: 60px 0 30px;
        }

        .footer-links {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .footer-section h4 {
            margin-bottom: 20px;
            color: white;
            font-size: 1.2rem;
        }

        .footer-section a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
            transition: color 0.3s ease;
        }

        .footer-section a:hover {
            color: white;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 20px;
            text-align: center;
            color: rgba(255,255,255,0.5);
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px 20px 0;
        }

        /* Animations */
        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0px);
            }
            50% {
                transform: translateY(-20px);
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-menu {
                display: none;
            }

            .hero-container {
                grid-template-columns: 1fr;
                gap: 40px;
                text-align: center;
            }

            .hero-content h1 {
                font-size: 2.5rem;
            }

            .features-grid, .plans-grid {
                grid-template-columns: 1fr;
            }

            .plan-card.featured {
                transform: none;
            }

            .section-header h2, .trust-section h2 {
                font-size: 2rem;
            }

            .phone-mockup {
                position: relative;
                right: auto;
                top: auto;
                margin: 20px auto;
            }

            .trust-section {
                padding: 80px 0;
            }

            .footer-links {
                grid-template-columns: 1fr;
                text-align: center;
            }
        }

        /* Scroll animations */
        .animate-on-scroll {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.6s ease-out;
        }

        .animate-on-scroll.animated {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>
<body>
    <!-- Header/Navigation -->
    <header class="header">
        <div class="nav-container">
            <div class="logo">
                <img src="/assets/images/logo-massola.png" alt="MassolaGroup Logo">
                <span class="logo-text">MassolaGroup Business</span>
            </div>
            <nav class="nav-menu">
                <a href="#features">Características</a>
                <a href="#plans">Planes</a>
                <a href="#trust">Transparencia</a>
                <a href="/signup/index.php">Registrarse</a>
                <a href="/signup/login.php">Entrar</a>
                <a href="/guiadecraciondenegocio/">Guía de creacion de negocio</a>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-container">
            <div class="hero-content">
                <h1>Transforma Tu Negocio con una Tienda Online Profesional</h1>
                <p>La plataforma más completa y fácil de usar para emprendedores cubanos. Comienza a vender online en minutos, sin complicaciones técnicas.</p>
                <a href="/signup/" class="cta-button">Comenzar Ahora</a>
            </div>
            <div class="hero-visual">
                <div class="hero-mockup">
                    <div class="desktop-mockup"></div>
                    <div class="phone-mockup"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features">
        <div class="section-header">
            <h2>Todo lo que Necesitas en un Solo Lugar</h2>
            <p>Diseñado específicamente para el mercado cubano, con todas las herramientas que tu negocio necesita para crecer</p>
        </div>
        <div class="features-grid">
            <div class="feature-card animate-on-scroll">
                <div class="feature-icon">⚡</div>
                <h3>Configuración Instantánea</h3>
                <p>Crea tu tienda en menos de 10 minutos. Solo sube tus productos y comienza a vender inmediatamente.</p>
            </div>
            <div class="feature-card animate-on-scroll">
                <div class="feature-icon">📱</div>
                <h3>Diseño Responsive</h3>
                <p>Tu tienda se verá perfecta en cualquier dispositivo: celulares, tablets y computadoras.</p>
            </div>
            <div class="feature-card animate-on-scroll">
                <div class="feature-icon">🔒</div>
                <h3>Seguridad Total</h3>
                <p>Plataforma segura con respaldo automático y protección de datos para tu tranquilidad.</p>
            </div>
            <div class="feature-card animate-on-scroll">
                <div class="feature-icon">📊</div>
                <h3>Analíticas Avanzadas</h3>
                <p>Mide el performance de tu tienda y toma decisiones basadas en datos reales.</p>
            </div>
            <div class="feature-card animate-on-scroll">
                <div class="feature-icon">📦</div>
                <h3>Gestión de Pedidos</h3>
                <p>Controla todos tus pedidos desde un panel intuitivo y fácil de usar.</p>
            </div>
            <div class="feature-card animate-on-scroll">
                <div class="feature-icon">🚀</div>
                <h3>Soporte 24/7</h3>
                <p>Nuestro equipo está siempre disponible para ayudarte cuando lo necesites.</p>
            </div>
        </div>
    </section>

    <!-- Trust and Transparency Section - CORREGIDA -->
    <section id="trust" class="trust-section">
        <div class="trust-container">
            <h2>Transparencia y Confianza</h2>
            <div class="trust-content">
                <p>Transparencia ante todo: En <strong>MassolaGroup</strong>, nos enfocamos en ofrecerte una plataforma sólida y confiable. Los productos, precios y contenidos publicados en los catálogos son responsabilidad exclusiva de cada negocio.</p>
                
                <p>Invitamos a todos nuestros usuarios y comerciantes a mantener prácticas responsables y cumplir con nuestras políticas de uso para garantizar una experiencia profesional y segura para todos.</p>
                
                <p>Visita <strong>MassolaGroup.com</strong> para conocer más sobre nuestra visión y servicios.</p>
            </div>
            <a href="https://massolagroup.com" class="trust-link" target="_blank">Conocer Más en MassolaGroup.com</a>
        </div>
    </section>

    <!-- Plans Section -->
    <section id="plans" class="plans">
        <div class="plans-container">
            <div class="section-header">
                <h2>Planes a Medida para Tu Negocio</h2>
                <p>Elige el plan perfecto que se adapte a las necesidades de tu emprendimiento</p>
            </div>
            <div class="plans-grid">
                <!-- Plan Básico -->
                <div class="plan-card animate-on-scroll" style="text-align:center;">
                    <div class="plan-header">
                        <div class="plan-name" style="margin:auto; display:inline-block;">Básico</div>
                    </div>
                    <p class="plan-price" style="font-size:2.2rem; font-weight:800; margin:18px 0; color:inherit; text-shadow: 0 6px 18px rgba(0,0,0,0.25);">
                      550 CUP/mes
                    </p>
                    <ul class="plan-features" style="display:inline-block; text-align:left;">
                        <li>Perfil de negocio</li>
                        <li>Gestión de pedidos</li>
                        <li>Categorías colapsables</li>
                        <li>Gestión de productos</li>
                        <li>Extras personalizables</li>
                        <li>Múltiples imágenes por elemento</li>
                        <li>SSL Gratuito</li>
                    </ul>
                    <div class="plan-pricing" style="margin-top:14px;">
                        <div class="plan-price" style="display:inline-block; text-align:left; max-width:320px;">
                            Suscripción semestral para residentes en Cuba con 15% de descuento. Por <strong>$2,805.00</strong> y ahorras <strong>$495.00</strong>.
                        </div>
                    </div>
                    <a href="/signup/?plan=basico" class="plan-button" style="display:inline-block; margin:18px auto;">Comenzar Ahora</a>
                </div>

                <!-- Plan Profesional -->
                <div class="plan-card featured animate-on-scroll" style="text-align:center;">
                    <div class="plan-header">
                        <div class="plan-name" style="margin:auto; display:inline-block;">Profesional</div>
                    </div>
                    <p class="plan-price" style="font-size:2.2rem; font-weight:800; margin:18px 0; color:inherit; text-shadow: 0 6px 18px rgba(0,0,0,0.25);">
                      750 CUP/mes
                    </p>
                    <ul class="plan-features" style="display:inline-block; text-align:left;">
                        <li>Productos ilimitados</li>
                        <li>Perfil de negocio</li>
                        <li>Gestión de pedidos</li>
                        <li>Categorías colapsables</li>
                        <li>Gestión de productos</li>
                        <li>Extras personalizables</li>
                        <li>Múltiples imágenes por elemento</li>
                        <li>Soporte prioritario</li>
                        <li>Estadísticas avanzadas</li>
                        <li>Sub-Dominio personalizado</li>
                        <li>SSL Gratuito</li>
                    </ul>
                    <div class="plan-pricing" style="margin-top:14px;">
                        <div class="plan-price" style="display:inline-block; text-align:left; max-width:340px;">
                            Suscripción semestral para residentes en Cuba con 15% de descuento. Por <strong>$3,825.00</strong> y ahorras <strong>$675.00</strong>.
                        </div>
                    </div>
                    <a href="/signup/?plan=profesional" class="plan-button" style="display:inline-block; margin:18px auto;">Elegir Plan</a>
                </div>


               <!-- Plan Empresa -->
                <div class="plan-card animate-on-scroll" style="text-align:center;">
                    <div class="plan-header">
                        <div class="plan-name" style="margin:auto; display:inline-block;">Empresa</div>
                    </div>
                    <p class="plan-price" style="font-size:2.2rem; font-weight:800; margin:18px 0; color:inherit; text-shadow: 0 6px 18px rgba(0,0,0,0.25);">
                      1500 CUP/mes
                    </p>
                    <ul class="plan-features" style="display:inline-block; text-align:left;">
                        <li>Productos ilimitados</li>
                        <li>Almacenamiento ilimitado</li>
                        <li>Perfil de negocio</li>
                        <li>Gestión de pedidos</li>
                        <li>Categorías colapsables</li>
                        <li>Gestión de productos</li>
                        <li>Extras personalizables</li>
                        <li>Múltiples imágenes por elemento</li>
                        <li>Soporte prioritario</li>
                        <li>Estadísticas avanzadas</li>
                        <li>Sub-Dominio personalizado</li>
                        <li>Reportes avanzados</li>
                        <li>SSL Gratuito</li>
                    </ul>
                    <div class="plan-pricing" style="margin-top:14px;">
                        <div class="plan-price" style="display:inline-block; text-align:left; max-width:360px;">
                            Suscripción semestral para residentes en Cuba con 15% de descuento. Por <strong>$7,650.00</strong> y ahorras <strong>$1,350.00</strong>.
                        </div>
                    </div>
                    <a href="/signup/?plan=premium" class="plan-button" style="display:inline-block; margin:18px auto;">Elegir Plan</a>
                </div>

            </div>
        </div>
    </section>

    <!-- Footer - MODIFICADO -->
    <footer class="footer">
        <div class="footer-links">
            <div class="footer-section">
                <h4>Empresa</h4>
                <a href="https://massolagroup.com" target="_blank">MassolaGroup.com</a>
                <a href="mailto:negociosonline@massolagroup.com">Contacto</a>
                <a href="#blog">Blog</a>
            </div>
            <div class="footer-section">
                <h4>Legal</h4>
                <a href="/terminos-servicios/">Términos de Servicios</a>
                <a href="/privacidad/">Política de Privacidad</a>
                <a href="/condiciones-uso/">Condiciones de Uso</a>
                <a href="/cookies/">Política de Cookies</a>
            </div>
            <div class="footer-section">
                <h4>Contacto</h4>
                <a href="mailto:negociosonline@massolagroup.com">negociosonline@massolagroup.com</a>
                <a href="tel:+5356697274">+53 5 6697274</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 MassolaGroup. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script>
        // Header scroll effect
        window.addEventListener('scroll', () => {
            const header = document.querySelector('.header');
            if (window.scrollY > 100) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });

        // Animaciones al hacer scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animated');
                }
            });
        }, observerOptions);

        // Observar elementos para animación
        document.addEventListener('DOMContentLoaded', () => {
            const animateElements = document.querySelectorAll('.animate-on-scroll');
            animateElements.forEach(el => observer.observe(el));
        });

        // Smooth scrolling para enlaces internos
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    </script>
</body>
</html>