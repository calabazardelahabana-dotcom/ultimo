<?php 
$pageTitle = "Administración - Massola Negocios";
include '../header.php'; 
?>

<section class="hero" style="background: var(--gradient-primary); padding: 6rem 0 4rem;">
    <div class="container">
        <h1 style="color: var(--white);">Panel de Administración</h1>
        <p style="color: var(--white); opacity: 0.95; font-size: 1.2rem;">
            Gestiona tu tienda online de forma simple y eficiente
        </p>
    </div>
</section>

<section style="padding: 4rem 0; background: var(--background-light);">
    <div class="container">
        <div class="form-container">
            <div style="text-align: center; margin-bottom: 2rem;">
                <div style="background: var(--gradient-primary); color: white; width: 60px; height: 60px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; font-size: 1.5rem;">
                    <i class="fas fa-sign-in-alt"></i>
                </div>
                <h3 style="color: var(--text-dark); margin-bottom: 0.5rem;">Iniciar Sesión</h3>
                <p style="color: var(--text-light;">Accede a tu panel de control</p>
            </div>
            
            <form id="login-form">
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> Correo Electrónico</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="tu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Contraseña</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="Tu contraseña" required>
                </div>
                
                <button type="submit" class="cta-button" style="width: 100%;">
                    <i class="fas fa-sign-in-alt"></i>
                    Iniciar Sesión
                </button>
                
                <p style="text-align: center; margin-top: 2rem; color: var(--text-light); font-size: 0.9rem;">
                    ¿No tienes cuenta? <a href="/signup/" style="color: var(--primary-color); font-weight: 600;">Regístrate aquí</a>
                </p>
            </form>
        </div>
    </div>
</section>

<?php include '../footer.php'; ?>