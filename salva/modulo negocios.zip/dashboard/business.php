<?php
// dashboard/business.php - Gestión del perfil del negocio
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_email'])) {
    header("Location: ../signup/login.php");
    exit();
}

$user_email = $_SESSION['user_email'];

// Cargar datos del usuario
$usuarios_dir = '../signup/usuarios/';
$user_file = $usuarios_dir . md5($user_email) . '.json';

if (!file_exists($user_file)) {
    header("Location: ../signup/plans.php");
    exit();
}

$user_data = json_decode(file_get_contents($user_file), true);

// Directorio para datos del negocio
$business_dir = 'business/';
if (!is_dir($business_dir)) {
    mkdir($business_dir, 0755, true);
}

$business_file = $business_dir . md5($user_email) . '.json';

// Cargar datos existentes del negocio o inicializar
if (file_exists($business_file)) {
    $business_data = json_decode(file_get_contents($business_file), true);
} else {
    $business_data = [
        'nombre_comercial' => '',
        'descripcion' => '',
        'telefono' => $user_data['telefono'] ?? '',
        'email_contacto' => $user_email,
        'direccion' => $user_data['direccion'] ?? '',
        'ciudad' => $user_data['ciudad'] ?? '',
        'sitio_web' => '',
        'redes_sociales' => [
            'facebook' => '',
            'instagram' => '',
            'twitter' => ''
        ],
        'horario' => [
            'lunes_viernes' => '9:00 AM - 6:00 PM',
            'sabado' => '9:00 AM - 2:00 PM',
            'domingo' => 'Cerrado'
        ],
        'colores' => [
            'primario' => '#3498db',
            'secundario' => '#2c3e50'
        ],
        'logo' => ''
    ];
}

// Procesar formulario si se envió
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Actualizar datos del negocio
    $business_data['nombre_comercial'] = trim($_POST['nombre_comercial'] ?? '');
    $business_data['descripcion'] = trim($_POST['descripcion'] ?? '');
    $business_data['telefono'] = trim($_POST['telefono'] ?? '');
    $business_data['email_contacto'] = trim($_POST['email_contacto'] ?? '');
    $business_data['direccion'] = trim($_POST['direccion'] ?? '');
    $business_data['ciudad'] = trim($_POST['ciudad'] ?? '');
    $business_data['sitio_web'] = trim($_POST['sitio_web'] ?? '');
    
    // Redes sociales
    $business_data['redes_sociales']['facebook'] = trim($_POST['facebook'] ?? '');
    $business_data['redes_sociales']['instagram'] = trim($_POST['instagram'] ?? '');
    $business_data['redes_sociales']['twitter'] = trim($_POST['twitter'] ?? '');
    
    // Horario
    $business_data['horario']['lunes_viernes'] = trim($_POST['horario_lv'] ?? '');
    $business_data['horario']['sabado'] = trim($_POST['horario_sabado'] ?? '');
    $business_data['horario']['domingo'] = trim($_POST['horario_domingo'] ?? '');
    
    // Colores
    $business_data['colores']['primario'] = $_POST['color_primario'] ?? '#3498db';
    $business_data['colores']['secundario'] = $_POST['color_secundario'] ?? '#2c3e50';
    
    // Guardar archivo
    file_put_contents($business_file, json_encode($business_data, JSON_PRETTY_PRINT));
    
    $success_message = "¡Perfil de negocio actualizado correctamente!";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Negocio - Massola Business</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --success: #2ecc71;
            --warning: #f39c12;
            --danger: #e74c3c;
            --light: #ecf0f1;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .dashboard-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }
        
        /* Sidebar (mismo que dashboard) */
        .sidebar {
            background: var(--primary);
            color: white;
            padding: 20px 0;
            position: fixed;
            width: 250px;
            height: 100vh;
            overflow-y: auto;
        }
        
        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid #34495e;
            margin-bottom: 20px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            color: white;
        }
        
        .logo span {
            color: var(--secondary);
        }
        
        .user-info {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid #34495e;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            background: var(--secondary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 2rem;
        }
        
        .user-name {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .user-email {
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        .nav-menu {
            list-style: none;
            padding: 0 15px;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #bdc3c7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .nav-link:hover, .nav-link.active {
            background: #34495e;
            color: white;
        }
        
        .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* Main Content */
        .main-content {
            grid-column: 2;
            padding: 30px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .header h1 {
            color: var(--primary);
            font-size: 2rem;
        }
        
        .logout-btn {
            background: var(--danger);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
        }
        
        .logout-btn:hover {
            background: #c0392b;
        }
        
        /* Business Form */
        .business-form {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .form-section {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .section-title {
            font-size: 1.3rem;
            color: var(--primary);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        
        .section-title i {
            margin-right: 10px;
            color: var(--secondary);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--primary);
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
            outline: none;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }
        
        .color-picker {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .color-input {
            width: 60px;
            height: 40px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .social-grid {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
        }
        
        .social-input {
            display: flex;
            align-items: center;
        }
        
        .social-input i {
            margin-right: 10px;
            color: #7f8c8d;
            width: 20px;
        }
        
        .btn-save {
            background: var(--success);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-save:hover {
            background: #27ae60;
            transform: translateY(-2px);
        }
        
        .success-message {
            background: #d4edda;
            color: var(--success);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }
            
            .main-content {
                grid-column: 1;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .social-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h1>Massola <span>Business</span></h1>
            </div>
            
            <div class="user-info">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="user-name"><?php echo htmlspecialchars($user_data['nombre']); ?></div>
                <div class="user-email"><?php echo htmlspecialchars($user_email); ?></div>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="index.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="business.php" class="nav-link active">
                        <i class="fas fa-store"></i>
                        Mi Negocio
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link">
                        <i class="fas fa-box"></i>
                        Productos
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link">
                        <i class="fas fa-shopping-cart"></i>
                        Pedidos
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Configuración
                    </a>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link">
                        <i class="fas fa-sign-out-alt"></i>
                        Cerrar Sesión
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Configuración de Mi Negocio</h1>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
            
            <?php if (isset($success_message)): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
            </div>
            <?php endif; ?>
            
            <div class="business-form">
                <form method="POST" action="">
                    <!-- Información Básica -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-info-circle"></i>
                            Información Básica
                        </h2>
                        
                        <div class="form-group">
                            <label for="nombre_comercial">Nombre Comercial *</label>
                            <input type="text" id="nombre_comercial" name="nombre_comercial" 
                                   class="form-control" value="<?php echo htmlspecialchars($business_data['nombre_comercial']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="descripcion">Descripción del Negocio</label>
                            <textarea id="descripcion" name="descripcion" class="form-control" 
                                      placeholder="Describe tu negocio, productos y servicios..."><?php echo htmlspecialchars($business_data['descripcion']); ?></textarea>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="telefono">Teléfono de Contacto *</label>
                                <input type="tel" id="telefono" name="telefono" 
                                       class="form-control" value="<?php echo htmlspecialchars($business_data['telefono']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="email_contacto">Email de Contacto *</label>
                                <input type="email" id="email_contacto" name="email_contacto" 
                                       class="form-control" value="<?php echo htmlspecialchars($business_data['email_contacto']); ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Ubicación -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-map-marker-alt"></i>
                            Ubicación
                        </h2>
                        
                        <div class="form-group">
                            <label for="direccion">Dirección *</label>
                            <input type="text" id="direccion" name="direccion" 
                                   class="form-control" value="<?php echo htmlspecialchars($business_data['direccion']); ?>" required>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="ciudad">Ciudad *</label>
                                <input type="text" id="ciudad" name="ciudad" 
                                       class="form-control" value="<?php echo htmlspecialchars($business_data['ciudad']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="sitio_web">Sitio Web</label>
                                <input type="url" id="sitio_web" name="sitio_web" 
                                       class="form-control" value="<?php echo htmlspecialchars($business_data['sitio_web']); ?>" 
                                       placeholder="https://tunegocio.com">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Redes Sociales -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-share-alt"></i>
                            Redes Sociales
                        </h2>
                        
                        <div class="social-grid">
                            <div class="form-group social-input">
                                <i class="fab fa-facebook"></i>
                                <input type="url" name="facebook" class="form-control" 
                                       value="<?php echo htmlspecialchars($business_data['redes_sociales']['facebook']); ?>" 
                                       placeholder="URL de Facebook">
                            </div>
                            <div class="form-group social-input">
                                <i class="fab fa-instagram"></i>
                                <input type="url" name="instagram" class="form-control" 
                                       value="<?php echo htmlspecialchars($business_data['redes_sociales']['instagram']); ?>" 
                                       placeholder="URL de Instagram">
                            </div>
                            <div class="form-group social-input">
                                <i class="fab fa-twitter"></i>
                                <input type="url" name="twitter" class="form-control" 
                                       value="<?php echo htmlspecialchars($business_data['redes_sociales']['twitter']); ?>" 
                                       placeholder="URL de Twitter">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Horario -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-clock"></i>
                            Horario de Atención
                        </h2>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="horario_lv">Lunes a Viernes</label>
                                <input type="text" id="horario_lv" name="horario_lv" 
                                       class="form-control" value="<?php echo htmlspecialchars($business_data['horario']['lunes_viernes']); ?>">
                            </div>
                            <div class="form-group">
                                <label for="horario_sabado">Sábado</label>
                                <input type="text" id="horario_sabado" name="horario_sabado" 
                                       class="form-control" value="<?php echo htmlspecialchars($business_data['horario']['sabado']); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="horario_domingo">Domingo</label>
                            <input type="text" id="horario_domingo" name="horario_domingo" 
                                   class="form-control" value="<?php echo htmlspecialchars($business_data['horario']['domingo']); ?>">
                        </div>
                    </div>
                    
                    <!-- Colores -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-palette"></i>
                            Colores de tu Tienda
                        </h2>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="color_primario">Color Primario</label>
                                <div class="color-picker">
                                    <input type="color" id="color_primario" name="color_primario" 
                                           class="color-input" value="<?php echo htmlspecialchars($business_data['colores']['primario']); ?>">
                                    <span><?php echo $business_data['colores']['primario']; ?></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="color_secundario">Color Secundario</label>
                                <div class="color-picker">
                                    <input type="color" id="color_secundario" name="color_secundario" 
                                           class="color-input" value="<?php echo htmlspecialchars($business_data['colores']['secundario']); ?>">
                                    <span><?php echo $business_data['colores']['secundario']; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-save">
                        <i class="fas fa-save"></i> Guardar Cambios
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Actualizar texto cuando cambian los colores
        document.getElementById('color_primario').addEventListener('input', function() {
            this.nextElementSibling.textContent = this.value;
        });
        
        document.getElementById('color_secundario').addEventListener('input', function() {
            this.nextElementSibling.textContent = this.value;
        });
    </script>
</body>
</html>