<?php
// dashboard/products.php - Gestión de productos
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_email'])) {
    header("Location: ../signup/login.php");
    exit();
}

$user_email = $_SESSION['user_email'];

// Cargar datos del usuario (asumiendo que tienes un sistema de archivos JSON)
$users_dir = '../signup/usuarios/';
$user_file = $users_dir . md5($user_email) . '.json';
$user_data = [];

if (file_exists($user_file)) {
    $user_data = json_decode(file_get_contents($user_file), true);
} else {
    // Datos por defecto si no existe el archivo
    $user_data = [
        'nombre' => 'Usuario',
        'email' => $user_email
    ];
}

// Directorio para datos de productos
$products_dir = 'products/';
if (!is_dir($products_dir)) {
    mkdir($products_dir, 0755, true);
}

$products_file = $products_dir . md5($user_email) . '.json';

// Cargar productos existentes o inicializar
if (file_exists($products_file)) {
    $products = json_decode(file_get_contents($products_file), true);
} else {
    $products = [];
}

// Procesar acciones
$success_message = '';
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'] ?? '';

    if ($action == 'add' || $action == 'edit') {
        $id = ($action == 'edit') ? $_POST['id'] : uniqid();
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $category = trim($_POST['category'] ?? '');
        $stock = intval($_POST['stock'] ?? 0);

        if (empty($name) || $price <= 0) {
            $error_message = "Nombre y precio son requeridos.";
        } else {
            $products[$id] = [
                'name' => $name,
                'description' => $description,
                'price' => $price,
                'category' => $category,
                'stock' => $stock,
                'created_at' => date('Y-m-d H:i:s')
            ];

            file_put_contents($products_file, json_encode($products, JSON_PRETTY_PRINT));
            $success_message = ($action == 'add') ? "Producto agregado correctamente." : "Producto actualizado correctamente.";
        }
    } elseif ($action == 'delete') {
        $id = $_POST['id'] ?? '';
        if (isset($products[$id])) {
            unset($products[$id]);
            file_put_contents($products_file, json_encode($products, JSON_PRETTY_PRINT));
            $success_message = "Producto eliminado correctamente.";
        } else {
            $error_message = "Producto no encontrado.";
        }
    }
}

// Obtener producto para editar
$edit_product = null;
$edit_id = $_GET['edit'] ?? '';
if (isset($products[$edit_id])) {
    $edit_product = $products[$edit_id];
}
?>