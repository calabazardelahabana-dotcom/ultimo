<?php
// dashboard/orders.php - Gestión de pedidos
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_email'])) {
    header("Location: ../signup/login.php");
    exit();
}

$user_email = $_SESSION['user_email'];

// Cargar datos del usuario (asumiendo que tienes un sistema de archivos JSON)
$users_dir = '../signup/usuarios/';
$user_file = $users_dir . md5($user_email) . '.json';
$user_data = [];

if (file_exists($user_file)) {
    $user_data = json_decode(file_get_contents($user_file), true);
} else {
    // Datos por defecto si no existe el archivo
    $user_data = [
        'nombre' => 'Usuario',
        'email' => $user_email
    ];
}

// Directorio para datos de pedidos
$orders_dir = 'orders/';
if (!is_dir($orders_dir)) {
    mkdir($orders_dir, 0755, true);
}

$orders_file = $orders_dir . md5($user_email) . '.json';

// Cargar pedidos existentes o inicializar
if (file_exists($orders_file)) {
    $orders = json_decode(file_get_contents($orders_file), true);
} else {
    $orders = [];
}

// Procesar acciones
$success_message = '';
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'] ?? '';

    if ($action == 'update_status') {
        $id = $_POST['id'] ?? '';
        $new_status = $_POST['new_status'] ?? '';
        
        if (isset($orders[$id])) {
            $orders[$id]['status'] = $new_status;
            $orders[$id]['updated_at'] = date('Y-m-d H:i:s');
            
            file_put_contents($orders_file, json_encode($orders, JSON_PRETTY_PRINT));
            $success_message = "Estado del pedido actualizado correctamente.";
        } else {
            $error_message = "Pedido no encontrado.";
        }
    }
}

// Simular algunos pedidos si no hay ninguno (para demo)
if (empty($orders)) {
    $orders = [
        uniqid() => [
            'cliente' => 'Juan Pérez',
            'email' => 'juan@ejemplo.com',
            'producto' => 'Producto Ejemplo',
            'cantidad' => 2,
            'total' => 1000,
            'status' => 'pendiente',
            'fecha' => date('Y-m-d H:i:s', strtotime('-1 day'))
        ],
        uniqid() => [
            'cliente' => 'María López',
            'email' => 'maria@ejemplo.com',
            'producto' => 'Servicio Premium',
            'cantidad' => 1,
            'total' => 1500,
            'status' => 'procesando',
            'fecha' => date('Y-m-d H:i:s', strtotime('-2 hours'))
        ]
    ];
    file_put_contents($orders_file, json_encode($orders, JSON_PRETTY_PRINT));
}
?>